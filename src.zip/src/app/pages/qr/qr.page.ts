import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
@Component({
  selector: 'app-qr',
  templateUrl: './qr.page.html',
  styleUrls: ['./qr.page.scss'],
})
export class QRPage implements OnInit {

  constructor(private menuController: MenuController,
    private navCtrl: NavController) { }

  ngOnInit() {
  }
  redireccionarqr() {
    this.navCtrl.navigateForward('/qr');
  }
  mostrarMenu(){
    this.menuController.open('first');
  }
}
